package com.Dao;

public interface UserDAO {

}
