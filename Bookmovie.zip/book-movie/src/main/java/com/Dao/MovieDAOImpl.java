package com.Dao;

public class MovieDAOImpl {

	public MovieDAOImpl() {
		// TODO Auto-generated constructor stub
	}

}
