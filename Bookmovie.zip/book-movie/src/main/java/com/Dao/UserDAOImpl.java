package com.Dao;

public class UserDAOImpl {

	public UserDAOImpl() {
		// TODO Auto-generated constructor stub
	}

}
