package com.Dao;

public interface MovieDAO {

}
