package com.Dto;

public class UserDTO {

	public UserDTO() {
		// TODO Auto-generated constructor stub
	}

}
