package com.Dto;

public class MovieDTO {

	public MovieDTO() {
		// TODO Auto-generated constructor stub
	}

}
