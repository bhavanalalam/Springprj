package com.controllers;

public class SeatLayoutController {

	public SeatLayoutController() {
		// TODO Auto-generated constructor stub
	}

}
