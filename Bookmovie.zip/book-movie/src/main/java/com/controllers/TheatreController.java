package com.controllers;

public class TheatreController {

	public TheatreController() {
		// TODO Auto-generated constructor stub
	}

}
