package com.controllers;

public class PaymentController {

	public PaymentController() {
		// TODO Auto-generated constructor stub
	}

}
