package com.controllers;

public class LoginController {

	public LoginController() {
		// TODO Auto-generated constructor stub
	}

}
