package com.controllers;

public class ProfileController {

	public ProfileController() {
		// TODO Auto-generated constructor stub
	}

}
