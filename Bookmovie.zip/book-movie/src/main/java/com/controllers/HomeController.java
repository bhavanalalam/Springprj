package com.controllers;

public class HomeController {

	public HomeController() {
		// TODO Auto-generated constructor stub
	}

}
