package com.controllers;

public class RegisterController {

	public RegisterController() {
		// TODO Auto-generated constructor stub
	}

}
