package com.controllers;

public class BookingController {

	public BookingController() {
		// TODO Auto-generated constructor stub
	}

}
