package com.controllers;

public class MovieController {

	public MovieController() {
		// TODO Auto-generated constructor stub
	}

}
