package in.sp.backend;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import in.sp.entity.UserIno;

@Controller
public class MyController {
	@GetMapping("/home")
	public String openHome() {
		return "hello";
	}
	@GetMapping("/Registration")
	public String openRegisterPage() {
		return "Registration";
	}
	@GetMapping("/login")
	public String openLoginPage() {
		return "login";
	}
	
	@PostMapping("/Registrationdata")

		public String RegisterData(  @RequestParam("name") String name, @RequestParam("email") String email, @RequestParam("password") String password) {
		

	    return "login"; 	
	}
	
	@PostMapping("/logindata")
	public String postData(@RequestParam("email") String email ,@RequestParam("password") String password,
			Model model) {
 
            return "profile"; 
        }
    }
	          
	    